</main>
        <footer>
            <p>&copy; <?= date('Y') ?> «Radiance». Все права защищены.</p>
        </footer>
        <script src="/assets/js/script.js"></script>
    </body>
</html>